export const sum = (a, b) => a + b;

export const milt = (a, b) => a * b;